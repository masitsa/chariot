<?php
	echo $this->load->view("home/slider", '', TRUE);
	//echo $this->load->view("home/about", '', TRUE);
	echo $this->load->view("home/services", '', TRUE);
	//echo $this->load->view("home/mail", '', TRUE);
	echo $this->load->view("gallery", '', TRUE);
	echo $this->load->view("contacts", '', TRUE);
?>
