
	<!-- Our Clients -->
	<div id="clients-flexslider" class="flexslider home clients">
        <div class="headline"><h3>Our Clients</h3></div>	
		<ul class="slides">
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client1_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client1.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client2_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client2.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client3_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client3.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client4_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client4.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client5_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client5.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client6_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client6.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client7_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client7.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client8_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client8.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client1_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client1.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client2_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client2.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client3_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client3.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client4_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client4.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client5_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client5.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client6_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client6.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client7_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client7.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client8_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client8.png" class="color-img" alt="" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url();?>assets/img/clients/client1_grey.png" alt="" />
                    <img src="<?php echo base_url();?>assets/img/clients/client1.png" class="color-img" alt="" />
                </a>
            </li>
        </ul>
	</div><!--/flexslider-->
	<!-- //End Our Clients -->