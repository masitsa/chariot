
<section id="mailus" class="dark_section parallax">
    <div class="container">
        <div class="row to_animate" data-animation="fadeInUp">
            <div class="col-sm-12 text-center">
                <h2 class="section_header">
                   Subscribe For News From Us
                </h2>                
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="widget widget_mailchimp to_animate" data-animation="fadeInUp">              
                    <form id="signup" action="/" method="get" class="form-inline">
                        <div class="form-group">
                            <input name="email" id="mailchimp_email" type="email" class="form-control" placeholder="your@email.com">
                        </div>
                        <button type="submit" class="theme_button">Send</button>
                        <div id="response"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>