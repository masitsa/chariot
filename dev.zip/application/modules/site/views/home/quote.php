
	
    <div class="row-fluid margin-bottom-30">
        <blockquote>
            <p><?php $motto = $contacts[0]->motto; echo $motto;?></p>
            <small>Chariot Photo Studio</small>
        </blockquote>
    </div>