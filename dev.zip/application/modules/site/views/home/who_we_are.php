<div class="row-fluid margin-bottom-30">
    	<!-- Who We Are -->
		<div class="span4">
			<div class="headline"><h3>Reasons to Choose Us</h3></div>
            <p>Award winning digital agency. We bring a personal and effective approach to every project we work on, which is why. Transform is an incredibly beautiful responsive Bootstrap Template for corporate professionals.</p>
            <ul class="superlist">
            	<li><i class="icon-ok"></i> Donec id elit non mi porta gravida</li>
            	<li><i class="icon-ok"></i> Corporate and Creative</li>
            	<li><i class="icon-ok"></i> Responsive Bootstrap Template</li>
            	<li><i class="icon-ok"></i> Corporate and Creative</li>
            	<li><i class="icon-ok"></i> Donec id elit non mi porta gravida</li>
            	<li><i class="icon-ok"></i> Donec id elit non mi porta gravida</li>

            </ul><br>


        </div><!--/span4-->

        <!-- Latest Shots -->
        <div class="span8">
			<div class="headline"><h3>Latest Shots</h3></div>
			<div class="latest-posts">
                <ul>
                    <li>
                        <img src="<?php echo base_url();?>assets/img/carousel/5.jpg">
                        <h5>Lorem ipsum dolor</h5>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Donec id elit non mi porta gravida at eget metus</p>
                        <a class="pull-right" href="#">Read More >></a>
                    </li>
                    <li>
                        <img src="<?php echo base_url();?>assets/img/carousel/4.jpg">
                        <h5>Lorem ipsum dolor</h5>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Donec id elit non mi porta gravida at eget metus</p>
                        <a class="pull-right" href="#">Read More >></a>
                    </li>
                </ul>
			</div>
        </div><!--/span8-->
	</div><!--/row-fluid-->	