<head>
    <title>Chariot Photo Studio</title>
    <meta charset="utf-8">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <![endif]-->
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

    <link rel="stylesheet" href="<?php echo base_url().'assets/themes/butterfly/'?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'assets/themes/butterfly/'?>css/main.css" id="color-switcher-link">
    <link rel="stylesheet" href="<?php echo base_url().'assets/themes/butterfly/'?>css/animations.css">
    <link rel="stylesheet" href="<?php echo base_url().'assets/themes/butterfly/'?>css/fonts.css">
    <script src="<?php echo base_url().'assets/themes/butterfly/'?>js/vendor/modernizr-2.6.2.min.js"></script>

    <!--[if lt IE 9]>
        <script src="<?php echo base_url().'assets/themes/butterfly/'?>js/vendor/html5shiv.min.js"></script>
        <script src="<?php echo base_url().'assets/themes/butterfly/'?>js/vendor/respond.min.js"></script>
    <![endif]-->
    <link rel="shortcut icon" href="<?php echo base_url()."assets/images/image_2014_02_07_14_40_48.jpg";?>">

</head>