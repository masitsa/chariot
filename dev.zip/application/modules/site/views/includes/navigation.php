    <header id="header">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <a href="./" class="navbar-brand"><span>Chariot Photo Studio</span></a>
                    <span id="toggle_mobile_menu"></span>
                    <nav id="mainmenu_wrapper">
                        <ul id="mainmenu" class="nav sf-menu">
                            <li class="">
                                <a href="#mainslider">Home</a>
                            </li>
                            <li class="">
                                <a href="#about_us">About Us</a>
                            </li>                                                          
                            <li class="">
                                <a href="#service">Services</a>
                             </li>
                             <!-- <li class="">
                                <a href="#teem">Teem</a>
                             </li>       
                            <li class="">
                               <a href="#prices">Price</a>
                            </li>   
                             <li class="">
                               <a href="#testimonials">Testimonials</a>
                            </li>
                            <li class="">
                               <a href="#post-blogs">Blog</a>
                            </li>   -->
                            <li class="">
                               <a href="#portfolio">Gallery</a>
                            </li>    
                            <li class="">
                               <a href="#contact">Contact</a>
                            </li>              
                        </ul>  
                    </nav>
                
                </div>
            </div>
        </div>
    </header>
	<input type="hidden" name="baseurl" id="baseurl" value="<?php echo site_url();?>"/>